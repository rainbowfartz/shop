import shelve

class CheckoutInfo:
    def __init__(self, id, name, address, card_number, exp_month, exp_year, cvv, date, difference, seed):
        self.__info_id = id
        self.__name = name 
        self.__address= address
        self.__card_number = card_number
        self.__exp_month = exp_month
        self.__exp_year = exp_year
        self.__cvv = cvv
        self.__date = date
        self.__difference = 0
        self.__seed= seed   
    
    def get_seed(self):
        return self.__seed
    def get_info_id(self):
        return self.__info_id
    def get_name(self):
        return self.__name 
    def get_address(self):
        return self.__address
    def get_card_number(self):
        return self.__card_number 
    def get_exp_month(self):
        return self.__exp_month
    def get_exp_year(self):
        return self.__exp_year
    def get_cvv(self):
        return self.__cvv
    def get_date(self):
        return self.__date
    def get_difference(self):
        return self.__difference

    def set_info_id(self, info_id):
        self.__info_id = info_id
    def set_name(self, name):
        self.__name = name
    def set_address(self, address):
        self.__address = address
    def set_card_number(self, card_number):
        self.__card_number = card_number
    def set_month(self, exp_month):
        self.__exp_month = exp_month
    def set_year(self, exp_year):
        self.__exp_year = exp_year
    def set_cvv(self, cvv):
        self.__cvv = cvv
    def set_date(self, date):
        self.__date = date
    def set_difference(self, difference):
        self.__difference = difference